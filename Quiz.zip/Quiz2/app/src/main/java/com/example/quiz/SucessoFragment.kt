package com.example.quiz

import androidx.fragment.app.Fragment

class SucessoFragment : Fragment(R.layout.sucesso_fragment) {
}