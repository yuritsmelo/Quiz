package com.example.quiz

import androidx.fragment.app.Fragment

class FalhaFragment : Fragment(R.layout.falha_fragment) {
}